/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from './game/GameEngine';
import { GameHUD } from './components/GameHUD';
import { TitleScreen } from './components/TitleScreen';
import { GameOverModal } from './components/GameOverModal';
import { SkinShopModal } from './components/SkinShopModal';
import { UserProfileModal } from './components/UserProfileModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { AdModal, AdType } from './components/AdModal';
import { ReviewModal } from './components/ReviewModal';
import { DailyChallengeModal } from './components/DailyChallengeModal';
import { DailyRaceResultsModal } from './components/DailyRaceResultsModal';
import { LEVELS } from './data/levels';
import { BALL_SKINS } from './data/skins';
import { BallSkin, GamePhase, GameStats, LeaderboardEntry, LevelConfig, UserProfile, DailyChallengeStatus } from './types/game';
import { soundEngine } from './audio/SoundEngine';
import { db, authReady, getCanonicalPlayerId, getAuthError } from './lib/firebase';
import { collection, doc, setDoc, onSnapshot } from 'firebase/firestore';
import {
  getTodayUtcDateString,
  getDailyChallengeLevel,
  fetchDailyRewardStatus,
  claimDailyRewardTransaction,
} from './lib/dailyChallenge';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Online / Offline Network Connection State
  const [isOnline, setIsOnline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const [phase, setPhase] = useState<GamePhase>('title');
  const [currentSkin, setCurrentSkin] = useState<BallSkin>(BALL_SKINS[0]);

  // Modals
  const [showShop, setShowShop] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showDailyChallengeModal, setShowDailyChallengeModal] = useState(false);
  const [showDailyRaceResultsModal, setShowDailyRaceResultsModal] = useState(false);
  const [dailyRaceResultsData, setDailyRaceResultsData] = useState<{
    stats: GameStats;
    racePosition: number;
    gemsAwarded: number;
    wasFirstRaceToday: boolean;
  } | null>(null);

  // Daily Challenge State & Universal UTC Date Tracking (Resets automatically at 00:00 UTC)
  const [currentUtcDate, setCurrentUtcDate] = useState<string>(getTodayUtcDateString);
  const [dailyStatus, setDailyStatus] = useState<DailyChallengeStatus | null>(null);
  const [isLoadingDailyStatus, setIsLoadingDailyStatus] = useState<boolean>(true);
  const [isDailyChallenge, setIsDailyChallenge] = useState<boolean>(false);
  const isDailyChallengeRef = useRef(false);
  isDailyChallengeRef.current = isDailyChallenge;

  // Ad Modal State
  const [adModal, setAdModal] = useState<{
    isOpen: boolean;
    type: AdType;
    skin?: BallSkin;
    adNumber?: number;
    totalAds?: number;
    onComplete?: () => void;
  }>({
    isOpen: false,
    type: 'level_complete',
  });

  const CURRENT_STORAGE_VERSION = 'v23.0_stable';

  // Safe non-destructive storage migration: NEVER wipes localStorage or resets legitimate user data
  useEffect(() => {
    try {
      const savedVersion = localStorage.getItem('going_hop_game_version');
      if (savedVersion !== CURRENT_STORAGE_VERSION) {
        // Validate game keys safely
        const safeParseInt = (key: string, min = 0): void => {
          const raw = localStorage.getItem(key);
          if (raw !== null) {
            const val = parseInt(raw, 10);
            if (!isNaN(val) && val >= min) {
              localStorage.setItem(key, val.toString());
            } else {
              localStorage.setItem(key, min.toString());
            }
          }
        };

        safeParseInt('going_hop_gems', 0);
        safeParseInt('going_hop_coins', 0);
        safeParseInt('going_hop_cum_score', 0);
        safeParseInt('going_hop_max_level', 1);

        try {
          const rawSkins = localStorage.getItem('going_hop_unlocked_skins');
          if (rawSkins) {
            const parsed = JSON.parse(rawSkins);
            if (!Array.isArray(parsed) || parsed.length === 0) {
              localStorage.setItem('going_hop_unlocked_skins', JSON.stringify(['classic_sphere']));
            }
          }
        } catch {
          localStorage.setItem('going_hop_unlocked_skins', JSON.stringify(['classic_sphere']));
        }

        localStorage.setItem('going_hop_game_version', CURRENT_STORAGE_VERSION);
      }
    } catch (err) {
      console.warn('Storage migration note:', err);
    }
  }, []);

  // Sequential Level Progression: Starts at Level 1 for new players; restores earned progress safely
  const [maxUnlockedLevel, setMaxUnlockedLevel] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('going_hop_max_level');
      if (saved) {
        const parsed = parseInt(saved, 10);
        if (!isNaN(parsed) && parsed >= 1 && parsed <= LEVELS.length) {
          return Math.max(3, parsed);
        }
      }
    } catch {
      // ignore
    }
    return 3;
  });

  // Player starts at Level 1 on game launch
  const [currentLevel, setCurrentLevel] = useState<LevelConfig>(LEVELS[0]);

  const currentLevelRef = useRef(currentLevel);
  currentLevelRef.current = currentLevel;

  // Dedicated snapshots for game-over and victory modals to ensure accurate non-zero stats
  const [victoryModalData, setVictoryModalData] = useState<{
    stats: GameStats;
    level: LevelConfig;
  } | null>(null);

  const [gameOverModalData, setGameOverModalData] = useState<{
    stats: GameStats;
    level: LevelConfig;
  } | null>(null);

  // Play background sound ONLY on the home/main page as requested
  useEffect(() => {
    if (phase === 'title') {
      soundEngine.startHomeAmbientMusic();
    } else {
      soundEngine.stopBackgroundMusic();
    }
  }, [phase]);

  // Initialize sound on user's first gesture anywhere
  useEffect(() => {
    const handleFirstGesture = () => {
      soundEngine.init();
      if (phase === 'title') {
        soundEngine.startHomeAmbientMusic();
      }
    };
    window.addEventListener('pointerdown', handleFirstGesture, { once: true });
    window.addEventListener('keydown', handleFirstGesture, { once: true });
    return () => {
      window.removeEventListener('pointerdown', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
    };
  }, [phase]);

  // Load player profile from persistent storage
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    try {
      const savedName = localStorage.getItem('going_hop_player_name');
      const savedCountry = localStorage.getItem('going_hop_player_country');
      const savedFlag = localStorage.getItem('going_hop_player_flag');
      if (savedName && savedCountry) {
        return {
          name: savedName,
          country: savedCountry,
          flag: savedFlag || '🇮🇳',
        };
      }
    } catch {
      // ignore
    }
    return null;
  });

  // Prompt player to enter Name & Country if not filled
  const [showProfileModal, setShowProfileModal] = useState<boolean>(() => {
    try {
      const savedName = localStorage.getItem('going_hop_player_name');
      const savedCountry = localStorage.getItem('going_hop_player_country');
      return !savedName || !savedCountry;
    } catch {
      return true;
    }
  });

  // Canonical Player ID derived from authenticated Firebase UID (Task 1)
  const [canonicalPlayerId, setCanonicalPlayerId] = useState<string | null>(() => {
    try {
      return localStorage.getItem('going_hop_canonical_uid') || getCanonicalPlayerId();
    } catch {
      return getCanonicalPlayerId();
    }
  });

  useEffect(() => {
    authReady.then((user) => {
      if (user) {
        setCanonicalPlayerId(user.uid);
        try {
          localStorage.setItem('going_hop_canonical_uid', user.uid);
        } catch {
          // ignore
        }
      }
    });
  }, []);

  // Fetch daily challenge status from Firebase whenever UID or UTC date changes
  useEffect(() => {
    authReady.then((user) => {
      const uid = user ? user.uid : (canonicalPlayerId || getCanonicalPlayerId());
      if (uid) {
        setIsLoadingDailyStatus(true);
        fetchDailyRewardStatus(uid, currentUtcDate)
          .then((status) => {
            setDailyStatus(status);
          })
          .catch((err) => {
            console.warn('[DailyChallenge] Initial status load notice:', err);
          })
          .finally(() => {
            setIsLoadingDailyStatus(false);
          });
      } else {
        setIsLoadingDailyStatus(false);
      }
    });
  }, [canonicalPlayerId, currentUtcDate]);

  // Automatic Daily Reset: Checks for UTC date rollover every 10 seconds (Requirement 5)
  useEffect(() => {
    const checkDateRollover = () => {
      const today = getTodayUtcDateString();
      if (today !== currentUtcDate) {
        console.log(`[DailyChallenge] Date rollover detected: ${currentUtcDate} -> ${today}. Resetting eligibility.`);
        setCurrentUtcDate(today);
        const uid = canonicalPlayerId || getCanonicalPlayerId();
        if (uid) {
          fetchDailyRewardStatus(uid, today).then((res) => {
            setDailyStatus(res);
          });
        }
      }
    };

    const timer = setInterval(checkDateRollover, 10000);
    return () => clearInterval(timer);
  }, [currentUtcDate, canonicalPlayerId]);

  // Load unlocked skins and ad progress on mount
  useEffect(() => {
    try {
      const savedUnlocked = JSON.parse(localStorage.getItem('going_hop_unlocked_skins') || '[]');
      const savedAds = JSON.parse(localStorage.getItem('going_hop_skin_ads') || '{}');
      if (Array.isArray(savedUnlocked)) {
        BALL_SKINS.forEach((skin) => {
          if (savedUnlocked.includes(skin.id)) {
            skin.unlocked = true;
          }
          const watched = Number(savedAds[skin.id]) || 0;
          if (watched > 0) {
            skin.adsWatched = watched;
            if (watched >= (skin.adsRequired || 2)) {
              skin.unlocked = true;
            }
          }
        });
      }
    } catch {
      // ignore
    }
  }, []);

  // Real Persistent Player Stats with boundary checks
  const [stats, setStats] = useState<GameStats>(() => {
    let savedGems = 0;
    let savedCoins = 0;
    let savedCumScore = 0;
    try {
      savedGems = Math.max(0, parseInt(localStorage.getItem('going_hop_gems') || '0', 10) || 0);
      savedCoins = Math.max(0, parseInt(localStorage.getItem('going_hop_coins') || '0', 10) || 0);
      savedCumScore = Math.max(0, parseInt(localStorage.getItem('going_hop_cum_score') || '0', 10) || 0);
    } catch {
      // ignore
    }

    return {
      score: 0,
      totalCumulativeScore: savedCumScore,
      coinsEarnedInLevel: 0,
      totalCoins: savedCoins,
      totalGems: savedGems,
      gemsCollectedInLevel: 0,
      totalGemsInLevel: LEVELS[0].totalGems,
      combo: 0,
      maxCombo: 0,
      targetPadsCleared: 0,
      totalTargetPads: LEVELS[0].targetPadsCount,
      currentLevel: LEVELS[0].id,
      perfectHits: 0,
    };
  });

  const userProfileRef = useRef(userProfile);
  userProfileRef.current = userProfile;
  const statsRef = useRef(stats);
  statsRef.current = stats;

  // Real Shared Multi-Device Firestore Global Leaderboard
  const [serverLeaderboard, setServerLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [isLeaderboardLoading, setIsLeaderboardLoading] = useState<boolean>(true);
  const [leaderboardError, setLeaderboardError] = useState<string | null>(null);

  // Sync locks, debounce, and high-water mark protection
  const isSyncingRef = useRef(false);
  const pendingSyncRef = useRef<{ score?: number; level?: number; gems?: number; force?: boolean } | null>(null);
  const lastSyncedGemsRef = useRef<number>(-1);
  const lastSyncedLevelRef = useRef<number>(-1);
  const lastSyncedScoreRef = useRef<number>(-1);
  const lastSyncTimeRef = useRef<number>(0);

  const syncPlayerScoreToServer = useCallback(
    async (scoreToSync?: number, levelToSync?: number, gemsToSync?: number, forceSync?: boolean) => {
      const profile = userProfileRef.current;
      if (!profile || !profile.name.trim()) return;

      // In-flight concurrency guard: if already syncing, queue the latest call
      if (isSyncingRef.current) {
        pendingSyncRef.current = { score: scoreToSync, level: levelToSync, gems: gemsToSync, force: forceSync };
        return;
      }

      isSyncingRef.current = true;
      try {
        const user = await authReady;
        const uid = user ? user.uid : getCanonicalPlayerId();
        if (!uid) {
          console.warn('[Firebase Diag] Skip sync: No authenticated canonical UID present yet.');
          return;
        }

        const curStats = statsRef.current;
        const rawGems = typeof gemsToSync === 'number' ? gemsToSync : curStats.totalGems;
        const rawScore = typeof scoreToSync === 'number' ? scoreToSync : curStats.totalCumulativeScore;
        const rawLevel = typeof levelToSync === 'number' ? levelToSync : curStats.currentLevel;

        const effectiveGems = Math.max(0, Math.min(10000000, isNaN(rawGems) ? 0 : rawGems));
        const effectiveScore = Math.max(0, Math.min(50000000, isNaN(rawScore) ? 0 : rawScore));
        const effectiveLevel = Math.max(1, Math.min(150, isNaN(rawLevel) ? 1 : rawLevel));

        // High-water mark protection: Never downgrade gems or level
        const finalGems = Math.max(effectiveGems, lastSyncedGemsRef.current);
        const finalLevel = Math.max(effectiveLevel, lastSyncedLevelRef.current);
        const finalScore = Math.max(effectiveScore, lastSyncedScoreRef.current);

        // Skip redundant writes if values haven't changed and not forced, unless 10 seconds have elapsed
        const now = Date.now();
        if (
          !forceSync &&
          finalGems === lastSyncedGemsRef.current &&
          finalLevel === lastSyncedLevelRef.current &&
          finalScore === lastSyncedScoreRef.current &&
          now - lastSyncTimeRef.current < 10000
        ) {
          return;
        }

        const playerDocRef = doc(db, 'leaderboard', uid);
        const payload = {
          id: uid,
          name: profile.name.trim().slice(0, 50),
          country: (profile.country || 'India').slice(0, 64),
          flag: (profile.flag || '🇮🇳').slice(0, 16),
          gems: finalGems,
          score: finalScore,
          level: finalLevel,
          updatedAt: now,
        };

        console.log('[Firebase Diag] Syncing canonical player score to Firestore:', payload);
        await setDoc(playerDocRef, payload, { merge: true });
        console.log('[Firebase Diag] Firestore setDoc succeeded for canonical UID:', uid);

        lastSyncedGemsRef.current = finalGems;
        lastSyncedLevelRef.current = finalLevel;
        lastSyncedScoreRef.current = finalScore;
        lastSyncTimeRef.current = now;
      } catch (err) {
        console.error('[Firebase Diag] Leaderboard sync error to Firestore:', err);
      } finally {
        isSyncingRef.current = false;
        // If another sync was requested while this one was running, process it now
        if (pendingSyncRef.current) {
          const next = pendingSyncRef.current;
          pendingSyncRef.current = null;
          syncPlayerScoreToServer(next.score, next.level, next.gems, next.force);
        }
      }
    },
    []
  );

  const syncRef = useRef(syncPlayerScoreToServer);
  syncRef.current = syncPlayerScoreToServer;

  // Real-time Firestore subscription with automatic deduplication & legacy consolidation
  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    let isMounted = true;
    setLeaderboardError(null);
    setIsLeaderboardLoading(true);

    // Timeout safety fallback after 6 seconds
    const timeoutTimer = setTimeout(() => {
      if (isMounted && isLeaderboardLoading) {
        console.warn('[Firebase Diag] Leaderboard loading timeout hit (6s). Clearing loading state.');
        setIsLeaderboardLoading(false);
      }
    }, 6000);

    authReady.then((user) => {
      if (!isMounted) return;

      if (!user) {
        clearTimeout(timeoutTimer);
        setIsLeaderboardLoading(false);
        const authErr = getAuthError();
        if (authErr?.code === 'auth/admin-restricted-operation' || authErr?.message?.includes('admin-restricted-operation')) {
          setLeaderboardError('Anonymous Authentication is disabled in Firebase Console. Please enable Anonymous sign-in under Firebase Authentication > Sign-in method.');
        } else {
          setLeaderboardError('Firebase Authentication initializing... check network connection.');
        }
        return;
      }

      setCanonicalPlayerId(user.uid);
      try {
        localStorage.setItem('going_hop_canonical_uid', user.uid);
      } catch {
        // ignore
      }

      console.log('[Firebase Diag] Subscribing to Firestore collection "leaderboard"...');
      const q = collection(db, 'leaderboard');
      unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!isMounted) return;
          clearTimeout(timeoutTimer);
          console.log('[Firebase Diag] onSnapshot received docs count:', snapshot.size);
          const rawDocs: any[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (data) {
              rawDocs.push({
                ...data,
                id: data.id || docSnap.id,
              });
            }
          });

          // === CANONICAL DEDUPLICATION & RECONCILIATION PIPELINE ===
          const currentUid = user.uid;
          const currentProfile = userProfileRef.current;
          let legacyStoredId: string | null = null;
          try {
            legacyStoredId = localStorage.getItem('going_hop_player_id');
          } catch {
            // ignore
          }

          // Build canonical records map keyed strictly by canonical UID (one entry per account)
          const canonicalMap = new Map<string, LeaderboardEntry>();
          let ownedLegacyDoc: any = null;

          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (!data) return;
            const docId = docSnap.id;

            // Handle legacy unauthenticated documents (ID format: 'player_...')
            if (docId.startsWith('player_') || docId.includes('_legacy_')) {
              // Verify ownership via client-side persistent storage
              if (legacyStoredId && docId === legacyStoredId) {
                ownedLegacyDoc = data;
              }
              // Legacy unauthenticated documents are preserved in Firestore
              // but excluded from the active canonical leaderboard to prevent duplicate rows.
              return;
            }

            // Canonical record keyed strictly by its authenticated Firebase UID
            const entryGems = typeof data.gems === 'number' && !isNaN(data.gems) ? Math.max(0, data.gems) : 0;
            const entryLevel = typeof data.level === 'number' && !isNaN(data.level) ? Math.max(1, data.level) : 1;
            const entryScore = typeof data.score === 'number' && !isNaN(data.score) ? Math.max(0, data.score) : 0;
            const entryUpdatedAt = typeof data.updatedAt === 'number' ? data.updatedAt : 0;

            canonicalMap.set(docId, {
              id: docId,
              name: typeof data.name === 'string' && data.name.trim() ? data.name.trim().slice(0, 50) : 'Player',
              country: typeof data.country === 'string' && data.country.trim() ? data.country.trim().slice(0, 64) : 'India',
              flag: typeof data.flag === 'string' && data.flag.trim() ? data.flag.trim().slice(0, 16) : '🇮🇳',
              gems: entryGems,
              score: entryScore,
              level: entryLevel,
              updatedAt: entryUpdatedAt,
              rank: 1,
              isCurrentUser: docId === currentUid,
            });
          });

          // Reconcile current player's canonical entry with local state & verified legacy progress
          const currentStats = statsRef.current;
          const existingCanonical = canonicalMap.get(currentUid);

          const bestGems = Math.max(
            existingCanonical?.gems || 0,
            ownedLegacyDoc?.gems || 0,
            currentStats.totalGems || 0
          );
          const bestLevel = Math.max(
            existingCanonical?.level || 1,
            ownedLegacyDoc?.level || 1,
            currentStats.currentLevel || 1
          );
          const bestScore = Math.max(
            existingCanonical?.score || 0,
            ownedLegacyDoc?.score || 0,
            currentStats.totalCumulativeScore || 0
          );
          const bestUpdatedAt = Math.max(
            existingCanonical?.updatedAt || 0,
            ownedLegacyDoc?.updatedAt || 0,
            Date.now()
          );

          if (existingCanonical) {
            existingCanonical.gems = bestGems;
            existingCanonical.level = bestLevel;
            existingCanonical.score = bestScore;
            existingCanonical.updatedAt = bestUpdatedAt;
            if (currentProfile?.name?.trim()) {
              existingCanonical.name = currentProfile.name.trim().slice(0, 50);
              existingCanonical.country = (currentProfile.country || existingCanonical.country).slice(0, 64);
              existingCanonical.flag = (currentProfile.flag || existingCanonical.flag).slice(0, 16);
            }
            canonicalMap.set(currentUid, existingCanonical);
          } else if (currentProfile?.name?.trim()) {
            // Player hasn't written to Firestore yet; include their canonical record
            canonicalMap.set(currentUid, {
              id: currentUid,
              name: currentProfile.name.trim().slice(0, 50),
              country: (currentProfile.country || 'India').slice(0, 64),
              flag: (currentProfile.flag || '🇮🇳').slice(0, 16),
              gems: bestGems,
              score: bestScore,
              level: bestLevel,
              updatedAt: bestUpdatedAt,
              rank: 1,
              isCurrentUser: true,
            });
          }

          // If the verified progress needs to be persisted back to the canonical document:
          if (
            currentProfile?.name?.trim() &&
            (!existingCanonical ||
              bestGems > (existingCanonical.gems || 0) ||
              bestLevel > (existingCanonical.level || 0) ||
              Boolean(ownedLegacyDoc))
          ) {
            syncRef.current(bestScore, bestLevel, bestGems, false);
          }

          // Deterministic Sort & Tie-Breaking across canonical accounts:
          // 1. Total Gems Collected (descending)
          // 2. Max Level reached (descending)
          // 3. Cumulative Score (descending)
          // 4. Earlier achievement updatedAt (ascending)
          // 5. Stable string comparison of canonical UID (deterministic)
          const sortedList = Array.from(canonicalMap.values()).sort((a, b) => {
            const gemsDiff = (b.gems || 0) - (a.gems || 0);
            if (gemsDiff !== 0) return gemsDiff;

            const levelDiff = (b.level || 0) - (a.level || 0);
            if (levelDiff !== 0) return levelDiff;

            const scoreDiff = (b.score || 0) - (a.score || 0);
            if (scoreDiff !== 0) return scoreDiff;

            const timeDiff = (a.updatedAt || 0) - (b.updatedAt || 0);
            if (timeDiff !== 0) return timeDiff;

            return a.id.localeCompare(b.id);
          });

          // Sequentially assign ranks strictly after canonical deduplication
          const formatted: LeaderboardEntry[] = sortedList.map((item, idx) => ({
            ...item,
            rank: idx + 1,
            isCurrentUser: item.id === currentUid,
          }));

          setServerLeaderboard(formatted);
          setIsLeaderboardLoading(false);
          setLeaderboardError(null);
        },
        (error) => {
          if (!isMounted) return;
          clearTimeout(timeoutTimer);
          console.error('[Firebase Diag] Firestore Leaderboard subscription error:', error);
          setIsLeaderboardLoading(false);
          setLeaderboardError(error.message || String(error));
        }
      );
    });

    return () => {
      isMounted = false;
      clearTimeout(timeoutTimer);
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // First launch or after update: user MUST fill Name & Country
  useEffect(() => {
    if (!userProfile) {
      setShowProfileModal(true);
    }
  }, [userProfile]);

  // Initialize GameEngine ONCE - NEVER destroyed mid-game!
  useEffect(() => {
    if (!mountRef.current) return;

    const engine = new GameEngine(mountRef.current, {
      onStatsUpdate: (newStats) => {
        const prevGems = statsRef.current.totalGems;
        setStats({ ...newStats });
        if (newStats.totalGems > prevGems) {
          syncRef.current(newStats.totalCumulativeScore, newStats.currentLevel, newStats.totalGems);
        }
      },
      onGameOver: async (finalStats) => {
        const snap = { ...finalStats };
        const activeLvl = currentLevelRef.current;

        // Daily Challenge race completion branch: player fell to abyss before finishing
        if (activeLvl.id === 9999 || isDailyChallengeRef.current) {
          const position = 3;
          await handleCompleteDailyRace(snap, position);
          return;
        }

        setGameOverModalData({ stats: snap, level: activeLvl });
        setStats(snap);
        setPhase('gameover');
        syncRef.current(finalStats.totalCumulativeScore, finalStats.currentLevel, finalStats.totalGems);
      },
      onVictory: async (finalStats) => {
        const snap = { ...finalStats };
        const completedLevel = currentLevelRef.current;

        // Daily Challenge race completion branch: player reached goal in actual finish order!
        if (completedLevel.id === 9999 || isDailyChallengeRef.current) {
          const position = snap.racePosition || 1;
          await handleCompleteDailyRace(snap, position);
          return;
        }

        setVictoryModalData({ stats: snap, level: completedLevel });
        setStats(snap);

        const nextLevelId = finalStats.currentLevel + 1;
        if (nextLevelId <= LEVELS.length) {
          setMaxUnlockedLevel((prev) => {
            const updated = Math.max(prev, nextLevelId);
            try {
              localStorage.setItem('going_hop_max_level', updated.toString());
            } catch {
              // ignore
            }
            return updated;
          });
        }

        syncRef.current(finalStats.totalCumulativeScore, finalStats.currentLevel, finalStats.totalGems);

        // When Level 2 is completed for the first time, ask user for star review!
        const shouldShowReview = completedLevel.id === 2 && !localStorage.getItem('going_hop_reviewed_v22');

        // When network connection is ON: Show ad immediately after level complete!
        // When network connection is OFF: Show victory screen directly without ad! NEVER jump to home page!
        if (typeof navigator !== 'undefined' && navigator.onLine) {
          setAdModal({
            isOpen: true,
            type: 'level_complete',
            onComplete: () => {
              setAdModal((prev) => ({ ...prev, isOpen: false }));
              setPhase('victory');
              if (shouldShowReview) {
                setShowReviewModal(true);
              }
            },
          });
        } else {
          // Offline mode: Go straight to victory screen with full stats
          setPhase('victory');
          if (shouldShowReview) {
            setShowReviewModal(true);
          }
        }
      },
      onPhaseChange: (newPhase) => {
        setPhase(newPhase);
      },
    });

    engineRef.current = engine;

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  const handleCompleteDailyRace = async (finalStats: GameStats, position: number) => {
    const user = await authReady;
    const uid = user ? user.uid : (canonicalPlayerId || getCanonicalPlayerId() || 'anonymous');
    const todayDate = currentUtcDate;

    console.log(`[DailyChallenge] Completing race for UID ${uid} on ${todayDate}. Position: ${position}`);
    const claimRes = await claimDailyRewardTransaction(
      uid,
      todayDate,
      position,
      statsRef.current.totalGems
    );

    const gemsAwarded = claimRes.gemsAwarded;
    const wasFirstRaceToday = !claimRes.alreadyClaimed && gemsAwarded > 0;

    if (gemsAwarded > 0) {
      const updatedTotalGems = claimRes.newTotalGems;
      setStats((prev) => ({
        ...prev,
        score: finalStats.score,
        targetPadsCleared: finalStats.targetPadsCleared,
        totalGems: updatedTotalGems,
      }));
      statsRef.current.totalGems = updatedTotalGems;
      syncPlayerScoreToServer(finalStats.totalCumulativeScore, undefined, updatedTotalGems, true);
      soundEngine.playLevelComplete();
    } else {
      setStats((prev) => ({
        ...prev,
        score: finalStats.score,
        targetPadsCleared: finalStats.targetPadsCleared,
      }));
    }

    setDailyStatus({
      date: todayDate,
      isClaimed: true,
      gemsAwarded: claimRes.alreadyClaimed ? (dailyStatus?.gemsAwarded ?? gemsAwarded) : gemsAwarded,
      position,
      claimedAt: Date.now(),
    });

    setDailyRaceResultsData({
      stats: finalStats,
      racePosition: position,
      gemsAwarded,
      wasFirstRaceToday,
    });

    setPhase('victory');
    setShowDailyRaceResultsModal(true);
  };

  const handleStartDailyRace = () => {
    setShowDailyChallengeModal(false);
    setShowDailyRaceResultsModal(false);
    setIsDailyChallenge(true);
    isDailyChallengeRef.current = true;
    const dailyLevel = getDailyChallengeLevel(currentUtcDate);
    setCurrentLevel(dailyLevel);
    engineRef.current?.setLevel(dailyLevel, false);
    engineRef.current?.startGame();
  };

  const handleReplayDailyRace = () => {
    setShowDailyRaceResultsModal(false);
    setIsDailyChallenge(true);
    isDailyChallengeRef.current = true;
    const dailyLevel = getDailyChallengeLevel(currentUtcDate);
    setCurrentLevel(dailyLevel);
    engineRef.current?.setLevel(dailyLevel, false);
    engineRef.current?.restartCurrentLevel();
  };

  const handleStartGame = () => {
    setIsDailyChallenge(false);
    isDailyChallengeRef.current = false;
    engineRef.current?.startGame();
  };

  const handlePlayAgain = () => {
    const lvl = (phase === 'victory' ? victoryModalData?.level : gameOverModalData?.level) ?? currentLevel;
    setCurrentLevel(lvl);
    engineRef.current?.setLevel(lvl, false);
    engineRef.current?.startGame();
  };

  const handleRestartLevel = () => {
    const lvl = (phase === 'victory' ? victoryModalData?.level : gameOverModalData?.level) ?? currentLevel;
    setCurrentLevel(lvl);
    engineRef.current?.setLevel(lvl, false);
    engineRef.current?.restartCurrentLevel();
  };

  const handleNextLevel = () => {
    const fromLevel = victoryModalData?.level ?? currentLevel;
    const nextIdx = fromLevel.id; // fromLevel.id is 1-indexed, next level is LEVELS[nextIdx]
    if (nextIdx < LEVELS.length) {
      const nextLvl = LEVELS[nextIdx];
      setCurrentLevel(nextLvl);
      engineRef.current?.setLevel(nextLvl, false);
      engineRef.current?.startGame();
    } else {
      handleGoHome();
    }
  };

  const handleGoHome = () => {
    setIsDailyChallenge(false);
    isDailyChallengeRef.current = false;
    setShowDailyChallengeModal(false);
    setShowDailyRaceResultsModal(false);
    setAdModal((prev) => ({ ...prev, isOpen: false }));
    engineRef.current?.resetGame();
    setPhase('title');
  };

  const handleTogglePause = () => {
    engineRef.current?.togglePause();
  };

  const handleSelectLevel = (level: LevelConfig) => {
    if (level.id <= maxUnlockedLevel) {
      setIsDailyChallenge(false);
      isDailyChallengeRef.current = false;
      setCurrentLevel(level);
      engineRef.current?.setLevel(level);
    }
  };

  const handleSelectSkin = (skin: BallSkin) => {
    setCurrentSkin(skin);
    engineRef.current?.setSkin(skin);
  };

  // Watch Ad to Continue / Revive from Defeat
  const handleWatchAdContinue = () => {
    if (!isOnline) return;
    setAdModal({
      isOpen: true,
      type: 'continue_revive',
      onComplete: () => {
        setAdModal((prev) => ({ ...prev, isOpen: false }));
        engineRef.current?.reviveAtCurrentPlatform();
      },
    });
  };

  // Watch Ad to Unlock a Ball Skin (2 Ads required per skin)
  const handleWatchSkinAd = (skin: BallSkin) => {
    if (!isOnline) return;
    const currentWatched = skin.adsWatched || 0;
    const nextWatched = currentWatched + 1;

    setAdModal({
      isOpen: true,
      type: 'skin_unlock',
      skin,
      adNumber: nextWatched,
      totalAds: skin.adsRequired || 2,
      onComplete: () => {
        setAdModal((prev) => ({ ...prev, isOpen: false }));
        skin.adsWatched = nextWatched;
        try {
          const adsMap = JSON.parse(localStorage.getItem('going_hop_skin_ads') || '{}');
          adsMap[skin.id] = nextWatched;
          localStorage.setItem('going_hop_skin_ads', JSON.stringify(adsMap));
        } catch {
          // ignore
        }

        if (nextWatched >= (skin.adsRequired || 2)) {
          skin.unlocked = true;
          try {
            const savedUnlocked = JSON.parse(localStorage.getItem('going_hop_unlocked_skins') || '[]');
            if (!savedUnlocked.includes(skin.id)) {
              savedUnlocked.push(skin.id);
              localStorage.setItem('going_hop_unlocked_skins', JSON.stringify(savedUnlocked));
            }
          } catch {
            // ignore
          }
          handleSelectSkin(skin);
          soundEngine.playLevelComplete();
        } else {
          soundEngine.playGemCollect();
        }
      },
    });
  };

  // Unlock Skin using Gold Coins (If online: play 1 ad before grant; If offline: grant directly)
  const handleUnlockSkin = (skin: BallSkin) => {
    const cost = skin.costCoins ?? skin.cost ?? 150;
    if (stats.totalCoins < cost) {
      soundEngine.playMiss();
      return;
    }

    const grantSkin = () => {
      skin.unlocked = true;
      const updatedCoins = stats.totalCoins - cost;
      const updatedStats = { ...stats, totalCoins: updatedCoins };
      setStats(updatedStats);
      try {
        localStorage.setItem('going_hop_coins', updatedCoins.toString());
        const savedUnlocked = JSON.parse(localStorage.getItem('going_hop_unlocked_skins') || '[]');
        if (!savedUnlocked.includes(skin.id)) {
          savedUnlocked.push(skin.id);
          localStorage.setItem('going_hop_unlocked_skins', JSON.stringify(savedUnlocked));
        }
      } catch {
        // ignore
      }
      handleSelectSkin(skin);
      soundEngine.playGemCollect();
    };

    if (isOnline) {
      setAdModal({
        isOpen: true,
        type: 'skin_coin_purchase',
        skin,
        onComplete: () => {
          setAdModal((prev) => ({ ...prev, isOpen: false }));
          grantSkin();
        },
      });
    } else {
      grantSkin();
    }
  };

  const handleSaveProfile = async (profile: UserProfile) => {
    setUserProfile(profile);
    setShowProfileModal(false);
    try {
      localStorage.setItem('going_hop_player_name', profile.name);
      localStorage.setItem('going_hop_player_country', profile.country);
      localStorage.setItem('going_hop_player_flag', profile.flag);
      localStorage.setItem('going_hop_game_version', CURRENT_STORAGE_VERSION);
    } catch {
      // ignore
    }

    // Immediately post new player to the server leaderboard so other gamers see them right away!
    await syncPlayerScoreToServer(stats.totalCumulativeScore, LEVELS[0].id, stats.totalGems, true);

    // Start fresh from Level 1: Sky Castle Islands on restart
    setCurrentLevel(LEVELS[0]);
    engineRef.current?.setLevel(LEVELS[0]);
    engineRef.current?.resetGame();
    setPhase('title');
  };

  return (
    <div 
      className="relative w-screen h-screen overflow-hidden"
      style={{ background: `linear-gradient(to bottom, ${currentLevel.bgTop}, ${currentLevel.bgBottom})` }}
    >
      {/* Three.js Isolated Canvas Container */}
      <div
        ref={mountRef}
        className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing"
      />

      {/* Title Screen Overlay */}
      {phase === 'title' && (
        <TitleScreen
          currentLevel={currentLevel}
          maxUnlockedLevel={maxUnlockedLevel}
          userProfile={userProfile}
          onSelectLevel={handleSelectLevel}
          onStartGame={handleStartGame}
          onOpenShop={() => setShowShop(true)}
          onOpenLeaderboard={() => {
            setShowLeaderboard(true);
            syncPlayerScoreToServer().catch((err) => console.warn('Background sync note:', err));
          }}
          onOpenProfile={() => setShowProfileModal(true)}
          onOpenDailyChallenge={() => setShowDailyChallengeModal(true)}
          dailyStatus={dailyStatus}
          currentSkin={currentSkin}
          totalGems={stats.totalGems}
          totalCoins={stats.totalCoins}
        />
      )}

      {/* In-Game Active HUD Overlay */}
      {(phase === 'playing' || phase === 'paused') && (
        <GameHUD
          stats={stats}
          currentLevel={currentLevel}
          isPaused={phase === 'paused'}
          onTogglePause={handleTogglePause}
          onRestartLevel={handleRestartLevel}
          onGoHome={handleGoHome}
          onSteerLeft={() => engineRef.current?.steerLeft()}
          onSteerRight={() => engineRef.current?.steerRight()}
          onJump={() => engineRef.current?.jump()}
        />
      )}

      {/* Standard Game Over / Victory Modal (Only shown for non-Daily Challenge runs) */}
      {(phase === 'gameover' || phase === 'victory') && !isDailyChallenge && (
        <GameOverModal
          stats={
            phase === 'victory'
              ? victoryModalData?.stats || stats
              : gameOverModalData?.stats || stats
          }
          currentLevel={
            phase === 'victory'
              ? victoryModalData?.level || currentLevel
              : gameOverModalData?.level || currentLevel
          }
          isVictory={phase === 'victory'}
          isOnline={isOnline}
          onPlayAgain={handlePlayAgain}
          onWatchAdContinue={handleWatchAdContinue}
          onNextLevel={
            (phase === 'victory'
              ? victoryModalData?.level || currentLevel
              : currentLevel
            ).id < LEVELS.length
              ? handleNextLevel
              : undefined
          }
          onGoHome={handleGoHome}
        />
      )}

      {/* Daily Challenge Overview Modal */}
      {showDailyChallengeModal && (
        <DailyChallengeModal
          isOpen={showDailyChallengeModal}
          onClose={() => setShowDailyChallengeModal(false)}
          onStartDailyRace={handleStartDailyRace}
          status={dailyStatus}
          isLoadingStatus={isLoadingDailyStatus}
        />
      )}

      {/* Daily Race Results Modal (Podium, Gems, and Repeat Race message) */}
      {showDailyRaceResultsModal && dailyRaceResultsData && (
        <DailyRaceResultsModal
          stats={dailyRaceResultsData.stats}
          racePosition={dailyRaceResultsData.racePosition}
          gemsAwarded={dailyRaceResultsData.gemsAwarded}
          wasFirstRaceToday={dailyRaceResultsData.wasFirstRaceToday}
          onRaceAgain={handleReplayDailyRace}
          onGoHome={handleGoHome}
        />
      )}

      {/* Ball Skin Shop Modal (10 skins, 5 via ads) */}
      {showShop && (
        <SkinShopModal
          currentSkin={currentSkin}
          totalCoins={stats.totalCoins}
          isOnline={isOnline}
          onSelectSkin={handleSelectSkin}
          onUnlockSkin={handleUnlockSkin}
          onWatchSkinAd={handleWatchSkinAd}
          onClose={() => setShowShop(false)}
        />
      )}

      {/* Real Multi-Device Global Leaderboard Modal (ZERO Fake Gamers) */}
      {showLeaderboard && (
        <LeaderboardModal
          entries={serverLeaderboard}
          loading={isLeaderboardLoading}
          error={leaderboardError}
          userProfile={userProfile}
          currentUserGems={stats.totalGems}
          onEditProfile={() => {
            setShowLeaderboard(false);
            setShowProfileModal(true);
          }}
          onRefresh={async () => {
            await syncPlayerScoreToServer();
          }}
          onClose={() => setShowLeaderboard(false)}
        />
      )}

      {/* User Profile Modal */}
      {showProfileModal && (
        <UserProfileModal
          initialProfile={userProfile || undefined}
          canClose={Boolean(userProfile)}
          onClose={() => setShowProfileModal(false)}
          onSave={handleSaveProfile}
        />
      )}

      {/* Monetized Rewarded & Interstitial Ad Modal */}
      {adModal.isOpen && (
        <AdModal
          type={adModal.type}
          skinName={adModal.skin?.name}
          adNumber={adModal.adNumber}
          totalAds={adModal.totalAds}
          onComplete={() => {
            adModal.onComplete?.();
          }}
          onClose={() => {
            setAdModal((prev) => ({ ...prev, isOpen: false }));
          }}
        />
      )}

      {/* Interactive 1 to 5 Star Game Review Modal (Triggered after Level 2) */}
      {showReviewModal && (
        <ReviewModal
          isOpen={showReviewModal}
          onSubmit={(rating, feedback) => {
            try {
              localStorage.setItem('going_hop_reviewed_v22', 'true');
              localStorage.setItem('going_hop_user_rating', rating.toString());
              if (feedback) localStorage.setItem('going_hop_user_feedback', feedback);
            } catch {
              // ignore
            }
            setShowReviewModal(false);
          }}
          onClose={() => {
            try {
              localStorage.setItem('going_hop_reviewed_v22', 'true');
            } catch {
              // ignore
            }
            setShowReviewModal(false);
          }}
        />
      )}
    </div>
  );
}
