import React, { useState } from 'react';
import { User, Globe, Sparkles, X, Home } from 'lucide-react';
import { UserProfile } from '../types/game';

interface UserProfileModalProps {
  onSave: (profile: UserProfile) => void;
  initialProfile?: UserProfile;
  canClose?: boolean;
  onClose?: () => void;
}

const COUNTRIES = [
  { name: 'India', flag: '🇮🇳' },
  { name: 'United States', flag: '🇺🇸' },
  { name: 'United Kingdom', flag: '🇬🇧' },
  { name: 'Brazil', flag: '🇧🇷' },
  { name: 'Japan', flag: '🇯🇵' },
  { name: 'Germany', flag: '🇩🇪' },
  { name: 'Canada', flag: '🇨🇦' },
  { name: 'Australia', flag: '🇦🇺' },
  { name: 'United Arab Emirates', flag: '🇦🇪' },
  { name: 'France', flag: '🇫🇷' },
  { name: 'Nepal', flag: '🇳🇵' },
  { name: 'Bangladesh', flag: '🇧🇩' },
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  onSave,
  initialProfile,
  canClose = false,
  onClose,
}) => {
  const [name, setName] = useState(initialProfile?.name || '');
  const [selectedCountry, setSelectedCountry] = useState(
    initialProfile?.country || ''
  );
  const [selectedFlag, setSelectedFlag] = useState(
    initialProfile?.flag || ''
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !selectedCountry) return;

    onSave({
      name: name.trim(),
      country: selectedCountry,
      flag: selectedFlag,
    });
  };

  return (
    <div className="absolute inset-0 bg-black/85 z-50 flex items-center justify-center p-4 select-none font-sans">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#1b0933] to-[#0a0219] border border-cyan-400/40 rounded-3xl p-6 md:p-8 flex flex-col items-center text-center shadow-[0_0_50px_rgba(0,240,255,0.35)] animate-in fade-in zoom-in-95 duration-200">
        {canClose && onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
        <div className="w-14 h-14 rounded-full bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center mb-3 shadow-[0_0_20px_rgba(0,240,255,0.4)]">
          <Sparkles className="w-7 h-7 text-cyan-300" />
        </div>

        <h2 className="text-2xl font-black text-white tracking-wide uppercase mb-1">
          PLAYER PROFILE &amp; LEADERBOARD
        </h2>
        <p className="text-xs text-cyan-300 font-medium mb-5">
          Enter your name and country to update your live leaderboard rank and start game
        </p>

        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-4 text-left">
          {/* Name Input */}
          <div>
            <label className="text-xs font-bold text-white/80 uppercase tracking-wider block mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-cyan-400" /> Enter Your Name
            </label>
            <input
              type="text"
              required
              maxLength={20}
              placeholder=""
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 focus:border-cyan-400 focus:outline-none text-white text-base font-semibold placeholder:text-white/35 transition-all shadow-inner"
            />
          </div>

          {/* Country Select */}
          <div>
            <label className="text-xs font-bold text-white/80 uppercase tracking-wider block mb-1.5 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-pink-400" /> Select Country
            </label>
            <select
              value={selectedCountry}
              onChange={(e) => {
                const c = COUNTRIES.find((item) => item.name === e.target.value);
                if (c) {
                  setSelectedCountry(c.name);
                  setSelectedFlag(c.flag);
                } else {
                  setSelectedCountry(e.target.value);
                }
              }}
              className="w-full px-4 py-3 rounded-xl bg-[#1a0a33] border border-white/20 focus:border-cyan-400 focus:outline-none text-white text-base font-semibold transition-all cursor-pointer"
            >
              <option value="" disabled className="text-white/40">Select your country...</option>
              {COUNTRIES.map((c) => (
                <option key={c.name} value={c.name} className="bg-[#1a0a33] text-white">
                  {c.flag} {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Submit CTA */}
          <button
            type="submit"
            disabled={!name.trim() || !selectedCountry}
            className="w-full mt-2 py-4 rounded-xl bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-500 hover:from-cyan-400 hover:to-pink-400 text-white font-extrabold text-base tracking-wider shadow-[0_0_25px_rgba(0,240,255,0.4)] transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transform active:scale-95 flex items-center justify-center gap-2"
          >
            <Home className="w-5 h-5 text-yellow-300 fill-yellow-300/30" />
            <span>SAVE PROFILE &amp; GO TO HOME</span>
          </button>
        </form>
      </div>
    </div>
  );
};
