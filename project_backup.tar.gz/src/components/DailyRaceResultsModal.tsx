import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Home, Trophy, Gem, CheckCircle2, AlertCircle } from 'lucide-react';
import { GameStats } from '../types/game';

interface DailyRaceResultsModalProps {
  stats: GameStats;
  racePosition: number; // 1, 2, or 3
  gemsAwarded: number; // 50, 15, or 0
  wasFirstRaceToday: boolean;
  onRaceAgain: () => void;
  onGoHome: () => void;
}

export const DailyRaceResultsModal: React.FC<DailyRaceResultsModalProps> = ({
  stats,
  racePosition,
  gemsAwarded,
  wasFirstRaceToday,
  onRaceAgain,
  onGoHome,
}) => {
  useEffect(() => {
    if (racePosition === 1) {
      try {
        confetti({
          particleCount: 110,
          spread: 90,
          origin: { y: 0.55 },
          colors: ['#ffd700', '#00f5ff', '#ff007f', '#39ff14'],
        });
      } catch {
        // Safe fallback
      }
    }
  }, [racePosition]);

  const positionTitle =
    racePosition === 1
      ? 'CHAMPION — 1ST PLACE!'
      : racePosition === 2
      ? 'RUNNER-UP — 2ND PLACE!'
      : '3RD PLACE FINISH';

  const positionEmoji = racePosition === 1 ? '🥇' : racePosition === 2 ? '🥈' : '🥉';
  const positionBadgeColor =
    racePosition === 1
      ? 'from-yellow-400 to-amber-500 text-black border-yellow-300'
      : racePosition === 2
      ? 'from-slate-200 to-slate-400 text-black border-slate-200'
      : 'from-amber-700 to-amber-900 text-white border-amber-500';

  return (
    <div className="fixed inset-0 z-40 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 select-none font-sans animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-gradient-to-b from-[#1c0836] via-[#100323] to-[#0a0118] border border-yellow-400/40 rounded-3xl p-6 md:p-8 flex flex-col items-center text-center shadow-[0_0_60px_rgba(255,200,0,0.3)] animate-in zoom-in-95 duration-200 max-h-[92vh] overflow-y-auto">
        {/* Crown / Trophy Avatar */}
        <div className="relative mb-3">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-yellow-400 via-amber-300 to-orange-500 flex items-center justify-center shadow-[0_0_30px_rgba(255,200,0,0.6)] text-4xl">
            {positionEmoji}
          </div>
          <div className="absolute -bottom-2 -right-2 w-7 h-7 rounded-full bg-black/90 border border-yellow-400/60 flex items-center justify-center text-xs">
            <Trophy className="w-4 h-4 text-yellow-400" />
          </div>
        </div>

        {/* Title & Placement */}
        <div className="mb-3">
          <span
            className={`inline-block px-3 py-1 rounded-full text-xs font-black tracking-wider uppercase mb-1 shadow-sm border bg-gradient-to-r ${positionBadgeColor}`}
          >
            {racePosition === 1 ? '🥇 Winner' : racePosition === 2 ? '🥈 2nd Place' : '🥉 3rd Place'}
          </span>
          <h2 className="text-2xl md:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-400 to-cyan-300 uppercase tracking-wide">
            {positionTitle}
          </h2>
          <p className="text-xs text-white/60 mt-0.5">
            Daily EDM Neon Championship Circuit
          </p>
        </div>

        {/* Gems Awarded Box */}
        <div className="w-full my-2 p-3.5 rounded-2xl bg-black/50 border border-white/10 flex items-center justify-between">
          <div className="text-left">
            <div className="text-[10px] text-white/50 uppercase font-bold tracking-wider">
              {wasFirstRaceToday ? 'Daily Reward Earned' : 'Race Completion'}
            </div>
            <div className="text-xs text-white/80 font-medium">
              {wasFirstRaceToday
                ? `Position #${racePosition} Reward`
                : 'Repeat race (0 extra gems)'}
            </div>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/20 border border-cyan-400/40">
            <Gem className="w-4 h-4 text-cyan-400 fill-cyan-400/40" />
            <span className="text-lg font-black text-white tabular-nums">
              +{gemsAwarded}
            </span>
          </div>
        </div>

        {/* Mandatory Requirement 4 Message Banner */}
        <div className="w-full p-3 rounded-2xl bg-yellow-500/15 border border-yellow-400/40 my-2 text-left flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
          <p className="text-xs text-yellow-200 font-semibold leading-relaxed">
            Today's reward claimed! You can race again, but no extra gems will be awarded today.
          </p>
        </div>

        {/* Breakdown Stats Grid */}
        <div className="w-full grid grid-cols-3 gap-2 my-2 bg-black/40 border border-white/5 rounded-2xl p-2.5">
          <div className="flex flex-col items-center">
            <span className="text-[10px] text-white/50 uppercase font-semibold">Score</span>
            <span className="text-sm font-bold text-white tabular-nums">
              {stats.score.toLocaleString()}
            </span>
          </div>
          <div className="flex flex-col items-center border-l border-white/10">
            <span className="text-[10px] text-white/50 uppercase font-semibold">Pads</span>
            <span className="text-sm font-bold text-cyan-300 tabular-nums">
              {stats.targetPadsCleared}/{stats.totalTargetPads}
            </span>
          </div>
          <div className="flex flex-col items-center border-l border-white/10">
            <span className="text-[10px] text-white/50 uppercase font-semibold">Max Combo</span>
            <span className="text-sm font-bold text-yellow-400 tabular-nums">
              x{stats.maxCombo || 1}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2 mt-3">
          {/* Unlimited Replay Button */}
          <button
            onClick={onRaceAgain}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400 text-black font-black text-sm tracking-wider shadow-[0_0_25px_rgba(255,200,0,0.45)] transition-all transform hover:scale-[1.02] active:scale-95 cursor-pointer flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4 text-black" />
            <span>RACE AGAIN (UNLIMITED)</span>
          </button>

          <button
            onClick={onGoHome}
            className="w-full py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 hover:text-white font-semibold text-xs transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Home className="w-4 h-4" />
            <span>MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
